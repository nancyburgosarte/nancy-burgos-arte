# 🚀 GUÍA COMPLETA — Nancy Burgos Arte con Panel de Admin
## GitHub + Netlify + Decap CMS · Todo gratis

---

## 📦 QUÉ ARCHIVOS TENÉS

```
nancy-burgos-arte/
├── index.html              ← La web principal
├── netlify.toml            ← Configuración de Netlify
├── admin/
│   ├── index.html          ← Panel de administración
│   └── config.yml          ← Configuración del CMS
├── content/
│   └── obras/
│       └── horizonte-quieto-i.md   ← Obra de ejemplo
└── static/
    └── uploads/            ← Aquí se guardarán tus fotos (lo llena el CMS)
```

---

## PASO 1 — Crear cuenta en GitHub (gratis)

GitHub es donde vive el código de tu web. Decap CMS guarda las obras ahí.

1. Andá a **https://github.com**
2. Clic en **"Sign up"**
3. Elegí un nombre de usuario (puede ser `nancyburgosarte`)
4. Confirmá el email

---

## PASO 2 — Crear un repositorio nuevo

Un repositorio es como una carpeta en la nube donde vive tu web.

1. Estando en GitHub, clic en el **"+"** arriba a la derecha → **"New repository"**
2. Nombre del repositorio: `nancy-burgos-arte`
3. Marcalo como **Public**
4. NO marques ninguna casilla extra
5. Clic en **"Create repository"**

---

## PASO 3 — Subir los archivos a GitHub

### Opción A — Desde la web de GitHub (más fácil)

1. En tu nuevo repositorio vacío, clic en **"uploading an existing file"**
2. Arrastrá **toda la carpeta** `nancy-burgos-arte` (o los archivos uno por uno)
3. Importante: Mantené la estructura de carpetas:
   - `index.html` va en la raíz
   - `netlify.toml` va en la raíz
   - `admin/index.html` va dentro de carpeta `admin`
   - `admin/config.yml` va dentro de carpeta `admin`
   - `content/obras/horizonte-quieto-i.md` va dentro de `content/obras`
4. Clic en **"Commit changes"** (botón verde)

### Opción B — Con GitHub Desktop (visual, recomendado para futuro)

1. Descargá **GitHub Desktop**: https://desktop.github.com
2. Cloná tu repositorio
3. Copiá los archivos a la carpeta
4. Clic en "Commit" y luego "Push"

---

## PASO 4 — Conectar Netlify con GitHub

1. Andá a **https://netlify.com** → creá cuenta (o ingresá)
2. Clic en **"Add new site"** → **"Import an existing project"**
3. Elegí **"GitHub"**
4. Autorizá a Netlify a acceder a GitHub
5. Seleccioná el repositorio `nancy-burgos-arte`
6. En configuración de build:
   - **Branch**: `main`
   - **Build command**: (dejalo vacío)
   - **Publish directory**: `.`
7. Clic en **"Deploy site"**
8. En 30 segundos tu sitio está online con una URL como `https://amazing-name-123.netlify.app`

---

## PASO 5 — Activar Netlify Identity (para el login del admin)

1. En tu sitio de Netlify, andá a **"Site configuration"** → **"Identity"**
2. Clic en **"Enable Identity"**
3. En **"Registration"** → cambiá a **"Invite only"** (para que solo vos puedas entrar)
4. Bajá hasta **"Services"** → **"Git Gateway"** → clic en **"Enable Git Gateway"**

---

## PASO 6 — Crear tu usuario de admin

1. En Netlify → **Identity** → clic en **"Invite users"**
2. Ingresá tu email: `nancyburgosbarrancos@gmail.com`
3. Revisá tu Gmail: vas a recibir un email de Netlify
4. Hacé clic en el link del email → te va a pedir crear una contraseña
5. ¡Listo! Ya tenés acceso al panel de admin

---

## PASO 7 — Entrar al panel de admin

1. Abrí en el navegador: `https://TU-SITIO.netlify.app/admin`
2. Te va a pedir login → ingresá con tu email y contraseña
3. ¡Ya estás en el panel!

---

## ✏️ CÓMO AGREGAR UNA OBRA NUEVA

1. Andá a `/admin` en tu sitio
2. Clic en **"Obras"** → **"Nueva obra"**
3. Completá:
   - **Título**: el nombre de la obra
   - **Técnica**: acrílico, óleo, mixta, etc.
   - **Medidas**: 80 × 80 cm
   - **Año**: 2024
   - **Fotos**: clic en "Agregar foto" → subí desde tu celular o computadora
   - **Descripción**: texto opcional
   - **Orden**: número (1 = primera, 2 = segunda, etc.)
4. Clic en **"Publicar"** arriba a la derecha
5. Esperá 30-60 segundos → la obra aparece en el sitio automáticamente

## 🗑 CÓMO ELIMINAR UNA OBRA

1. En el panel → **"Obras"**
2. Buscá la obra → clic en los tres puntos `···` → **"Eliminar"**
3. El sitio se actualiza solo

## 📸 CÓMO AGREGAR MÁS FOTOS A UNA OBRA EXISTENTE

1. En el panel → abrí la obra
2. En la sección **"Fotos de la obra"** → clic en **"Agregar foto"**
3. Subí la foto nueva
4. Clic en **"Publicar"**

---

## 📱 ¿PUEDO HACERLO DESDE EL CELULAR?

Sí. El panel `/admin` funciona en cualquier navegador móvil.
Podés subir fotos directamente desde la galería del celular.

---

## 🌍 CAMBIAR EL NOMBRE DEL SITIO (URL)

En Netlify → **Site configuration** → **General** → **Site details** → **Change site name**
Ejemplo: `nancyburgosarte` → `https://nancyburgosarte.netlify.app`

---

## 💡 CONSEJOS PARA LAS FOTOS

- **Formato**: JPG o WEBP (mejor que PNG para fotos)
- **Tamaño**: entre 800px y 2000px de ancho — ni muy chicas ni muy grandes
- **Peso**: idealmente menos de 2MB por foto
- **Cantidad**: podés subir hasta 8 fotos por obra
- **Nombres de archivo**: sin espacios ni tildes (ej: `horizonte-quieto-2024.jpg`)

---

## ❓ PROBLEMAS FRECUENTES

**El sitio no se actualiza después de publicar**
→ Esperá 1-2 minutos. Si no, andá a Netlify → Deploys y verificá que el deploy esté "Published"

**No puedo entrar al admin**
→ Verificá que hayas aceptado la invitación del email de Netlify

**Las fotos no se ven**
→ Verificá que el archivo se subió correctamente en el panel. Asegurate que el nombre no tenga espacios.

---

*Sistema preparado para Nancy Burgos Arte · Paraná, Argentina*
