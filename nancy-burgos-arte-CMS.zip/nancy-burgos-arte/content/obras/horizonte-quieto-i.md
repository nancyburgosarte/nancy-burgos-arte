titulo: Horizonte Quieto I
tecnica: Acrílico y textura
medidas: 120 × 90 cm
anio: 2024
descripcion: >
  Una composición que invita a la calma. Los tonos celestes y beige se
  fusionan en capas de textura que evocan la quietud del horizonte al
  atardecer. Pensada para espacios que buscan serenidad.
orden: 1
fotos:
  - foto: /uploads/horizonte-quieto-i-1.jpg
